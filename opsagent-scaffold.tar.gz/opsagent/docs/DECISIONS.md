# Decisions

Append only. One entry per choice that closes off an alternative.

Format: D<n>, date, the decision, the alternatives rejected, and why.

---

## D1, 10 October 2026, separate repo from chatbot-lab

OpsAgent is its own repository, not a third product folder inside
chatbot-lab. Rejected keeping it inside, because the production stack here
(Temporal, Postgres, Redis, LiteLLM, OTel) would drag chatbot-lab's simple
learning setup into infrastructure it does not need, and because
chatbot-lab's shared/llm.py cannot carry tool calls or message history.

## D2, 10 October 2026, grade by database state

Cases are graded by comparing the final database state to an annotated goal
state, borrowed from tau2-bench. Rejected grading the agent's prose, and
rejected an LLM judge as the primary grader, because the assertions that
matter here are deterministic and a judge adds noise and cost to a question
that has an exact answer.

## D3, 10 October 2026, Pydantic AI over LangGraph

Pydantic AI 2.0 is the agent framework. Rejected LangGraph 1.x, which is
stronger on checkpointing and interrupt for approval but heavier than this
product needs at the start. Revisit at Beat 9 if human in the loop approval
becomes a product requirement rather than an escalation.

## D4, 10 October 2026, caps and limits in code

The refund cap, the authorisation check, and the idempotency guarantee live
in the tool layer and in database constraints. Rejected stating them in the
prompt. A filter in the prompt is advice. A filter in SQL is a rule, and
PolicyDesk already proved the prompt version gets ignored.
