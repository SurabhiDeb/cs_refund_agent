# Glossary

Every term, in plain English. Add to it the first time a term appears.

**Agent loop** The cycle where the model picks a tool, the tool runs, the
result goes back to the model, and it picks again until it answers or stops.

**Trajectory** The whole sequence of one run. Every message, tool call,
argument, and tool result. Not just the final answer.

**Tool call** The model asking for a named function to be run with specific
arguments. The model does not run it. Your code does.

**Goal state** What the database should look like after a correct run. Written
before the agent exists, so it cannot be bent to match the agent.

**Idempotency key** A value attached to a write so that sending the same write
twice has the effect of sending it once.

**Kill switch** One flag that disables every write tool, leaving the agent
able to read and to escalate only.

**Durable execution** A workflow that survives a crash and resumes from where
it stopped, rather than restarting and repeating side effects. Temporal's job.

**Compensation** The undo step for a write that was already made when a later
step failed.

**Escalation** Handing the case to a human. The correct answer whenever the
agent is uncertain, over cap, or cannot parse its own output.

**Prompt injection** Text in the input, or in a tool result, that tries to
make the model ignore its instructions. Planting it in tool results is the
realistic attack.

**Wilson interval** A confidence interval for a pass rate that stays sensible
on small samples. 19 out of 20 is "somewhere between 76 and 99 percent".

**tau2-bench** An external benchmark of multi turn customer service agents in
retail, airline, and telecom domains, graded by final database state.

**Testcontainers** A library that starts a real Postgres in Docker for a test
and throws it away afterwards, so tests run against the real thing.
